def saludo(name):
    return f"Hola, {name}!"

if __name__ == "__main__":
    print(saludo("Jharvy"))